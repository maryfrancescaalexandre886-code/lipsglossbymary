LIPS GLOSS BY MARY — NETLIFY/GITHUB

Upload the contents of this folder to the GitHub repository connected to your Netlify project:
  maryfrancescaalexandre886-code/lipsglossbymary

Important: index.html must be in the ROOT of the repository. The images folder and style.css must be alongside index.html.

Netlify settings for this simple static site:
- Build command: leave empty
- Publish directory: .
- Base directory: leave empty

The site uses the supplied Lips Gloss by Mary product image.
